I completed the tutorial "Make Your First Platformer in GameMaker" (gamemaker.io), which guides you through creating a basic platformer similar to Super Mario. I built the blocks, added the player, and implemented lose and win conditions using spikes and a final stage.

Modifications:

Theme: I developed a new theme called "MClimb," where the player must reach Mount M.
New Functionality: The player must collect a golden stone while avoiding obstacles before ascending the mountain.
Scenarios:

If the player reaches the mountain without collecting the stone, a message displays: "Stone missing."
If the player reaches the mountain with the stone, a message displays: "You are Oredigger," indicating the player has won.
If the player collides with the cyan-colored spikes, the game restarts.